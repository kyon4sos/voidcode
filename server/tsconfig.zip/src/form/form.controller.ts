import { Controller } from '@nestjs/common';

@Controller('form')
export class FormController {}
